1)Authentification
-You must enter your email and passeword
-Then you have to presss the button "Login" to access the page of BMI Calculator
NB:The email and the password you must be used is:
email : admin@gmail.com
password : awokou
2)The page of BMI Calculator
-You must choose the unit in which the height will be
-You must choose the unit in which the weight will be
-In others words you will enter your height in meters and your weight in kilograms
-then you have to press the calculate button
-The calculate button will then give you a result and a message
-The message will explain to you if you are lean or overweight depending on your height in relation to your weight